import json
import os

data_path = "data"

def reload_data():
    global Teachers, Courses, Questions

    Teachers = json.load(open(os.path.join(data_path, 'teachers.json')))
    Courses = json.load(open(os.path.join(data_path, 'courses.json')))
    Questions = json.load(open(os.path.join(data_path, 'questions.json')))
    Forms = json.load(open(os.path.join(data_path, 'forms.json')))

Teachers = json.load(open(os.path.join(data_path, 'teachers.json')))
Courses = json.load(open(os.path.join(data_path, 'courses.json')))
Questions = json.load(open(os.path.join(data_path, 'questions.json')))
Forms = json.load(open(os.path.join(data_path, 'forms.json')))


def get_teacher(teacher_id, password):
    for teacher in Teachers:
        if teacher['teacher_id'] == teacher_id and teacher['password'] == password:
            return teacher
        
def add_teacher(teacher_id, password, name):
    try:
        Teachers.append({
            'teacher_id': teacher_id,
            'password': password,
            'name': name
        })
        json.dump(Teachers, open('teachers.json', 'w'))
    except:
        return False


def get_cource(cource_id):
    for cource in Courses:
        if cource['course_id'] == cource_id:
            return cource
        
    return None

def add_cource(cource_id, name, teacher_id):
    Courses.append({
        'course_id': cource_id,
        'name': name,
        'teacher_id': teacher_id
    })
    json.dump(Courses, open('courses.json', 'w'))

def get_teacher_cources(teacher_id):
    return [cource for cource in Courses if cource['teacher_id'] == teacher_id]

def get_questions():
    return Questions

def add_form(form):
    form_id = "FRm"+ str(len(Forms) + 1)
    form['form_id'] = form_id
    Forms.append(form)
    json.dump(Forms, open('forms.json', 'w'))
