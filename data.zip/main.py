import tkinter as tk
import customtkinter as ctk
from PIL import Image
from auth import get_teacher, get_questions, reload_data
import os

# Constants
WINDOW_SIZE = 1080, 800
Factor = 0.3, 0.4
Pages_factor = 0.2




# Image and Path
imgs_path = 'imgs/'
ethronics_img = Image.open(os.path.join(imgs_path, 'ethronics.jpg'))
ethronics_icon = os.path.join(imgs_path, 'ethronics.ico')


# Default theme
ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")


class FrontPage(ctk.CTk):
    def __init__(self):
        super().__init__()

        # Set the window title
        self.title('Ethronics - Feedback Form')

        self.iconbitmap(ethronics_icon)

        # Set window size
        self.geometry(f'{WINDOW_SIZE[0]}x{WINDOW_SIZE[1]}')

        # Load the Ethronics image
        self.ethronics_image = ctk.CTkImage(ethronics_img, size=(WINDOW_SIZE[0]*Factor[0], WINDOW_SIZE[1]*Factor[1]))

        # Create an image label
        self.image_label = ctk.CTkLabel(self, text="", image=self.ethronics_image)
        self.image_label.pack(pady=20)

        # Create the title label
        self.title_label = ctk.CTkLabel(self, text='Ethronics - Feedback Form', font=("Arial", 20))
        self.title_label.pack(pady=10)

        # Create theme option
        self.theme_var = tk.StringVar(value="Light")
        self.theme_menu = ctk.CTkOptionMenu(self, values=["Light", "Dark"], variable=self.theme_var, command=self.change_theme)
        self.theme_menu.pack(pady=10)

        # Button to fill a feedback form (will lead to another page later)
        self.form_button = ctk.CTkButton(self, text="Fill Feedback Form", command=self.go_to_form)
        self.form_button.pack(pady=10)

        # Button to log in as teacher (will lead to login page)
        self.login_button = ctk.CTkButton(self, text="Teacher Login", command=self.go_to_login)
        self.login_button.pack(pady=10)

    def change_theme(self, new_theme):
        # Update the theme based on selection
        if new_theme == "Dark":
            ctk.set_appearance_mode("dark")
        else:
            ctk.set_appearance_mode("light")

    def go_to_form(self):
        self.destroy()
        feedback_form = FeedbackForm()
        feedback_form.mainloop()

    def go_to_login(self):
        self.destroy()
        login_page = LoginPage()
        login_page.mainloop()



class LoginPage(ctk.CTk):
    def __init__(self):
        super().__init__()

        # Set the window title
        self.title('Ethronics - Teacher Login')

        # Set window size
        self.geometry(f'{WINDOW_SIZE[0]}x{WINDOW_SIZE[1]}')

        # Load the Ethronics image
        self.ethronics_image = ctk.CTkImage(ethronics_img, size=(WINDOW_SIZE[0]*Factor[0]*Pages_factor, WINDOW_SIZE[1]*Factor[1]*Pages_factor))

        # Create an image label
        self.image_label = ctk.CTkLabel(self, text="", image=self.ethronics_image)
        self.image_label.pack(pady=20)

        # Create the title label
        self.title_label = ctk.CTkLabel(self, text='Ethronics - Teacher Login', font=("Arial", 20))
        self.title_label.pack(pady=10)

        # Create the teacher ID entry
        self.teacher_id_label = ctk.CTkLabel(self, text="Teacher ID")
        self.teacher_id_label.pack(pady=10)
        self.teacher_id_entry = ctk.CTkEntry(self)
        self.teacher_id_entry.pack(pady=10)

        # Create the password entry
        self.password_label = ctk.CTkLabel(self, text="Password")
        self.password_label.pack(pady=10)
        self.password_entry = ctk.CTkEntry(self, show="*")
        self.password_entry.pack(pady=10)

        # Button to log in
        self.login_button = ctk.CTkButton(self, text="Login", command=self.login)
        self.login_button.pack(pady=10)

        # Button to go back to front page
        self.back_button = ctk.CTkButton(self, text="Back", command=self.go_back)
        self.back_button.pack(pady=10)

    def login(self):
        teacher_id = self.teacher_id_entry.get()
        password = self.password_entry.get()

        teacher = get_teacher(teacher_id, password)
        if teacher:
            self.destroy()
            teacher_page = TeacherPage(teacher_id)
            teacher_page.mainloop()
        else:
            print("Login failed")

    def go_back(self):
        self.destroy()
        front_page = FrontPage()
        front_page.mainloop()
        

class TeacherPage(ctk.CTk):
    def __init__(self, teacher_id):
        super().__init__()

        # Set the window title
        self.title('Ethronics - Teacher Page')

        # Set window size
        self.geometry(f'{WINDOW_SIZE[0]}x{WINDOW_SIZE[1]}')

        # Load the Ethronics image
        self.ethronics_image = ctk.CTkImage(ethronics_img, size=(WINDOW_SIZE[0]*Factor[0]*Pages_factor, WINDOW_SIZE[1]*Factor[1]*Pages_factor))

        # Create an image label
        self.image_label = ctk.CTkLabel(self, text="", image=self.ethronics_image)
        self.image_label.pack(pady=20)

        # Create the title label
        self.title_label = ctk.CTkLabel(self, text='Ethronics - Teacher Page', font=("Arial", 20))
        self.title_label.pack(pady=10)

        # Button to view courses
        self.view_courses_button = ctk.CTkButton(self, text="View Courses", command=self.view_courses)
        self.view_courses_button.pack(pady=10)

        # Button to log out
        self.logout_button = ctk.CTkButton(self, text="Logout", command=self.logout)
        self.logout_button.pack(pady=10)


    def view_courses(self):
        # Placeholder function for viewing courses
        print("Viewing courses...")

    def logout(self):
        self.destroy()
        front_page = FrontPage()
        front_page.mainloop()

class FeedbackForm(ctk.CTk):
    def __init__(self):
        super().__init__()

        # Set the window title
        self.title('Ethronics - Feedback Form')

        # Set window size
        self.geometry(f'{WINDOW_SIZE[0]}x{WINDOW_SIZE[1]}')

        # Load the Ethronics image
        self.ethronics_image = ctk.CTkImage(ethronics_img, size=(WINDOW_SIZE[0]*Factor[0]*Pages_factor, WINDOW_SIZE[1]*Factor[1]*Pages_factor))

        # Create an image label
        self.image_label = ctk.CTkLabel(self, text="", image=self.ethronics_image)
        self.image_label.place(y=0, x=0)

        # Create the title label
        self.title_label = ctk.CTkLabel(self, text='Ethronics - Feedback Form', font=("Arial", 20))
        self.title_label.pack(pady=10)

        # Create the feedback form
        self.questions_list = get_questions()
        initialx, initialy = WINDOW_SIZE[0]*.1, WINDOW_SIZE[1]*.05
        increment_factor = 50
        x_increment_factor = 100
        initialy_options = 550
        self.questions = {}
        for idx, question in enumerate(self.questions_list):
            question_text = f"{idx+1}. {question['question']}"
            question_type = question['type']
            question_id = question['question_id'],
            print("IDDDDD\n\n\n\n", question_id)
            self.questions[question['question_id']] = {'type':question_type, 'values':[]}
            if question_type == 'tickbox':
                options = question['options']
                self.question_label = ctk.CTkLabel(self, text=question_text)
                self.question_label.place(y=initialx+increment_factor*idx, x=initialy)
                self.question_checkboxes = []
                for idx2, option in enumerate(options):
                    checkbox = ctk.CTkCheckBox(self, text=option, command=lambda :self.toggle_checkboxes(question_id, option))
                    self.questions[question['question_id']]['values'].append({'label':option, 'component':checkbox})
                    checkbox.place(y=initialx+increment_factor*idx, x=initialy_options+x_increment_factor*idx2)
                    self.question_checkboxes.append(checkbox)
            elif question_type == "rate":
                options = question['options']
                self.question_label = ctk.CTkLabel(self, text=question_text)
                self.question_label.place(y=initialx+increment_factor*idx, x=initialy)
                self.question_checkboxes = []
                for idx2, option in enumerate(options):
                    checkbox = ctk.CTkCheckBox(self, text=option, command=lambda :self.toggle_checkboxes(question_id, option))
                    self.questions[question['question_id']]['values'].append({'label':option, 'component':checkbox})
                    checkbox.place(y=initialx+increment_factor*idx, x=initialy_options+x_increment_factor*idx2)
                    self.question_checkboxes.append(checkbox)
            else:
                self.question_label = ctk.CTkLabel(self, text=question_text)
                self.question_label.place(y=initialx+increment_factor*idx, x=initialy)
                self.question_entry = ctk.CTkEntry(self)
                self.question_entry.place(y=initialx+increment_factor*idx, x=initialy_options+initialy)

        # Button to submit feedback
        self.submit_button = ctk.CTkButton(self, text="Submit", command=self.submit)
        self.submit_button.place(y=initialx+increment_factor*(idx+1), x=WINDOW_SIZE[1]*.5)

        # Button to go back to teacher page
        self.back_button = ctk.CTkButton(self, text="Back", command=self.go_back)
        self.back_button.place(y=initialx+increment_factor*(idx+2), x=WINDOW_SIZE[1]*.5)

    def submit(self):
        # Placeholder function for submitting feedback
        temp_dict = self.questions.copy()
        for key, value in temp_dict.items():
            print([i['component'].get() for i in value['values']])
        print("Submitting feedback...")

    def go_back(self):
        self.destroy()
        front_page = FrontPage()
        front_page.mainloop()

    def toggle_checkboxes(self, question_id, name_of_tickbox):
        temp_dict = self.questions.copy()
        for key, value in temp_dict.items():
            print(key)
            print([i['component'].get() for i in value['values']])
        print('toggle called', question_id)
        questions = self.questions[question_id]['values']
        print(questions)
        for question in questions:
            print(question['label'], name_of_tickbox)
            if question['label'] != name_of_tickbox:
                question['component'].deselect()


def main():
    app = FeedbackForm()
    app.mainloop()

if __name__ == '__main__':
    main()
